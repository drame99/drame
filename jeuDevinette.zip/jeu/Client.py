import tkinter as tk
import socket
import threading
import mysql.connector
from tkinter import messagebox

# Paramètres de connexion
HOST = "localhost"
PORT = 9098

# Paramètres de la base de données MySQL
DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = ""
DB_DATABASE = "Jeu"

# Création de la connexion à la base de données
db_connection = mysql.connector.connect(
    host=DB_HOST,
    user=DB_USER,
    password=DB_PASSWORD
)
db_cursor = db_connection.cursor()

# Création de la base de données si elle n'existe pas
db_cursor.execute("CREATE DATABASE IF NOT EXISTS {}".format(DB_DATABASE))
db_connection.database = DB_DATABASE

# Création de la table "users" si elle n'existe pas
db_cursor.execute("""CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(255) NOT NULL,
                    password VARCHAR(255) NOT NULL)"""
                )
db_connection.commit()

def login_user(username, password):
    # Vérification des informations de connexion
    db_cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
    user = db_cursor.fetchone()

    if user:
        return True  # Les informations de connexion sont correctes

    return False  # Les informations de connexion sont incorrectes

def register_user(username, password):
    # Vérification si l'utilisateur existe déjà
    db_cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = db_cursor.fetchone()

    if user:
        return False  # L'utilisateur existe déjà

    # Insertion du nouvel utilisateur dans la base de données
    db_cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
    db_connection.commit()

    return True  # L'utilisateur a été enregistré avec succès

def listen_for_messages(client_socket):
    while True:
        message = client_socket.recv(1024).decode()
        display_message(f"Serveur : {message}\n")  # Afficher la réponse du serveur dans la zone de texte
        if "Le jeu est terminé" in message:
            break

def send_message():
    message = message_entry.get()
    display_message(f"Nombre saisi: {message}\n")  # Afficher le message du client dans la zone de texte
    client_socket.sendall(message.encode())
    message_entry.delete(0, tk.END)  # Vider le champ de saisie

def display_message(message):
    text_area.insert(tk.END, message)  # Ajouter le message à la zone de texte
    text_area.see(tk.END)  # Faire défiler automatiquement vers la fin de la zone de texte

def connect_to_server():
    # Connexion au serveur
    global client_socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))

    # Réception du message d'accueil
    message = client_socket.recv(1024).decode()
    display_message(f"Bienvenue à l'interface de mon jeu\n {message}\n")  # Afficher le message d'accueil dans la zone de texte

    # Démarrer un thread pour écouter les messages du serveur
    message_thread = threading.Thread(target=listen_for_messages, args=(client_socket,))
    message_thread.start()

def close_connection():
    # Fermeture de la connexion client
    client_socket.close()
    root.destroy()

def login():
    username = username_entry.get()
    password = password_entry.get()

    if not username or not password:
        messagebox.showerror("Erreur", "Veuillez saisir un nom d'utilisateur et un mot de passe.")
        return

    if login_user(username, password):
        # Mise à jour de l'étiquette avec le nom d'utilisateur
        username_label_game.config(text=f"NOM CLIENT : {username}")
        connect_to_server()
        # Cacher le menu de connexion et afficher le jeu
        login_frame.pack_forget()
        game_frame.pack()
    else:
        messagebox.showerror("Erreur", "Informations de connexion incorrectes. Veuillez réessayer.")

def register():
    username = username_entry.get()
    password = password_entry.get()

    if not username or not password:
        messagebox.showerror("Erreur", "Veuillez saisir un nom d'utilisateur et un mot de passe.")
        return

    if register_user(username, password):
        messagebox.showinfo("Succès", "Inscription réussie. Veuillez vous connecter.")
        username_entry.delete(0, tk.END)
        password_entry.delete(0, tk.END)
    else:
        messagebox.showerror("Erreur", "Cet utilisateur existe déjà. Veuillez choisir un autre nom d'utilisateur.")

# Création de la fenêtre principale
root = tk.Tk()
root.configure(bg="green")
root.title("Mon application Jeu de devinette")

# Frame de connexion
login_frame = tk.Frame(root)
login_frame.pack()
username_label = tk.Label(login_frame, text='Nom d\'utilisateur :')
username_label.grid(row=0, column=0, padx=10, pady=10)

username_entry = tk.Entry(login_frame)
username_entry.grid(row=0, column=1, padx=10, pady=10)

password_label = tk.Label(login_frame, text='Mot de passe :')
password_label.grid(row=1, column=0, padx=10, pady=10)

password_entry = tk.Entry(login_frame, show='*')
password_entry.grid(row=1, column=1, padx=10, pady=10)

# Bouton pour s'inscrire
register_button = tk.Button(login_frame, text="S'inscrire", command=register)
register_button.grid(row=2, column=0, padx=20, pady=5)

# Bouton pour se connecter au serveur
connect_button = tk.Button(login_frame, text="Se connecter", command=login)
connect_button.grid(row=2, column=1, padx=20, pady=5)

# Frame du jeu
game_frame = tk.Frame(root)
game_frame.configure(bg="green")

# Étiquette pour afficher le nom d'utilisateur
username_label_game = tk.Label(game_frame, text="", font=("Helvetica", 12, "bold"), bg="green", fg="white")
username_label_game.pack(pady=10)

# Zone de texte pour afficher les messages du client et du serveur
text_area = tk.Text(game_frame, borderwidth=2, relief="sunken")
text_area.pack()

# Champ de saisie du message
message_entry = tk.Entry(game_frame)
message_entry.pack(side=tk.LEFT, fill=tk.X, padx=10, pady=10)

# Bouton pour envoyer le message
send_button = tk.Button(game_frame, text="Envoyer", command=send_message)
send_button.pack(side=tk.LEFT, padx=10, pady=10)

# Bouton pour fermer la connexion et quitter l'application
close_button = tk.Button(game_frame, text="Fermer", command=close_connection)
close_button.pack(side=tk.LEFT, padx=10, pady=10)

# Lancement de la boucle principale
root.mainloop()
