import socket
import random
import threading

# Paramètres de connexion
HOST = "localhost"
PORT = 9098

# Génération d'un nombre aléatoire entre 1 et 100
x = random.randint(1, 100)

# Variables pour gérer les connexions clients
client_connections = []
client_lock = threading.Lock()

# État du jeu
game_state = {
    "number_found": False,
    "winning_client": None
}


# Fonction pour envoyer un message à tous les clients
def send_to_all_clients(message, sender_socket):
    with client_lock:
        for client_socket in client_connections:
            if client_socket != sender_socket:
                if client_socket == game_state["winning_client"]:
                    client_socket.sendall(f"Bravo, vous avez gagné ! Le NOMBRE SECRET était : {x}\n".encode())
                else:
                    client_socket.sendall(message.encode())
                # Informer les autres clients du nombre secret
                if client_socket != game_state["winning_client"]:
                    client_socket.sendall(f"Le nombre secret était : {x}\n".encode())

        # Envoyer le message "Game Over" à tous les clients
        for client_socket in client_connections:
            client_socket.sendall(f"Le gagnant est {game_state['winning_client'].getpeername()} ! Le jeu est terminé\n".encode())


# Fonction pour gérer la connexion d'un client
def handle_client_connection(client_socket):
    # Ajouter la connexion client à la liste
    with client_lock:
        client_connections.append(client_socket)

    # Envoyer le message d'accueil au client
    client_socket.sendall( "Déviner un nombre compris entre 0 ET 100: \n".encode())

    while True:
        # Réception de la proposition du client
        y = int(client_socket.recv(1024).decode())

        # Vérification de l'état du jeu
        with client_lock:
            if game_state["number_found"]:
                # Informer le client que le nombre a déjà été trouvé par un autre joueur
                client_socket.sendall(f"Quelqu'un a déjà trouvé le NOMBRE SECRET.\n".encode())
                break

        # Vérification de la proposition
        if x == y:
            # Mettre à jour l'état du jeu pour indiquer que le nombre a été trouvé
            with client_lock:
                game_state["number_found"] = True
                game_state["winning_client"] = client_socket

            # Informer tous les clients que le nombre a été trouvé
            send_to_all_clients("Quelqu'un a trouvé le NOMBRE SECRET !", None)
            break
        elif x < y:
            client_socket.sendall("Le nombre saisi est plus Grand du nombre à déviner  !\n".encode())
        else:
            client_socket.sendall("Le nombre saisi est plus Petit du nombre à déviner  !\n".encode())

    # Fermer la connexion client et la supprimer de la liste
    with client_lock:
        client_socket.close()
        client_connections.remove(client_socket)

# Création de la socket serveur
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen()

print(f"Le serveur attend une connexion sur le port {PORT}")

while True:
    # Attente de la connexion d'un client
    client_socket, address = server_socket.accept()
    print(f"Le client {address} est connecté")

    # Création d'un thread pour gérer la connexion du client
    client_thread = threading.Thread(target=handle_client_connection, args=(client_socket,))
    client_thread.start()
